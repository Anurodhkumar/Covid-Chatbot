# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

# from typing import Any, Text, Dict, List
#
# from rasa_sdk import Action, Tracker
# from rasa_sdk.executor import CollectingDispatcher
#
#
# class ActionHelloWorld(Action):
#
#     def name(self) -> Text:
#         return "action_hello_world"
#
#     def run(self, dispatcher: CollectingDispatcher,
#             tracker: Tracker,
#             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
#
#         dispatcher.utter_message(text="Hello World!")
#
#         return []


import requests
from rasa_sdk import Action, Tracker
from typing import Any, Text, Dict, List
from rasa_sdk.executor import CollectingDispatcher
import pymongo



class Actionbill(Action):
    def name(self) -> Text:
         return "action_pincode"

    def run(self,
           dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
         pincode=''
         place=''
         cases=''
         pincode=tracker.get_slot("pincode")
         tracker.slots.clear() 
         print(tracker.sender_id)
         response = requests.get("https://api.postalpincode.in/pincode/"+str(int(pincode)))
         district = response.json()[0]["PostOffice"][0]["District"]
         state = response.json()[0]["PostOffice"][0]["Circle"]
         response = requests.get("https://api.covid19india.org/state_district_wise.json")
         cases = response.json()[state]["districtData"][district]['confirmed']
         print(cases)
         dispatcher.utter_message(template="utter_hello_pincode",place=district,pincode=pincode,cases=cases)
         return []

class Actionhello(Action):
    def name(self) -> Text:
         return "action_hello"

    def run(self,
           dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
         user=''

         user=tracker.get_slot("user")
         tracker.slots.clear() 
         #user.append(append)
         print(tracker.sender_id)
         print(user)
         dispatcher.utter_message(template="utter_hello_user",user=user)
         return [] 


class Actioncity(Action):
    def name(self) -> Text:
         return "action_city"

    def run(self,
           dispatcher: CollectingDispatcher,
           tracker: Tracker,
           domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
         
         place=''
         
         place=tracker.get_slot("place")
         tracker.slots.clear() 
         
         response = requests.get("https://api.covid19india.org/state_district_wise.json")
         cases = response.json()[place]
         print(cases)
         dispatcher.utter_message(template="utter_hello_place",place=place,cases=cases)
         return []         